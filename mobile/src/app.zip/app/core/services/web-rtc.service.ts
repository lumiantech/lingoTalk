import {
    Injectable,
    Service,
    signal
} from '@angular/core';

import {
    Capacitor,
    registerPlugin
} from '@capacitor/core';

interface SpeechRecognitionNativePlugin {

    pushAudio(options: {
        data: string;
    }): Promise<void>;
}

const SpeechRecognition =
    registerPlugin<SpeechRecognitionNativePlugin>(
        'SpeechRecognition'
    );

@Injectable()
export class WebRtcService {

    private peerConnection?: RTCPeerConnection;
    private pendingIceCandidates: RTCIceCandidateInit[] = [];

    private localStream?: MediaStream;
    private remoteStream?: MediaStream;

    private audioContext?: AudioContext;
    private audioSourceNode?: MediaStreamAudioSourceNode;
    private audioWorkletNode?: AudioWorkletNode;

    readonly localMediaStream =
        signal<MediaStream | null>(null);

    readonly remoteMediaStream =
        signal<MediaStream | null>(null);

    readonly callConnected =
        signal(false);

    readonly callState =
        signal<RTCPeerConnectionState>(
            'new'
        );

    async initializeMedia(): Promise<MediaStream> {

        if (this.localStream) {
            return this.localStream;
        }

        this.localStream =
            await navigator.mediaDevices.getUserMedia({
                video: {
                    facingMode: 'user'
                },

                audio: {
                    echoCancellation: true,
                    noiseSuppression: true,
                    autoGainControl: true
                }
            });

        this.localMediaStream.set(
            this.localStream
        );

        return this.localStream;
    }

    async createPeerConnection(
        onIceCandidate:
            (candidate: RTCIceCandidateInit) => void,
        forceNew = false
    ): Promise<RTCPeerConnection> {

        if (
            forceNew &&
            this.peerConnection
        ) {

            this.peerConnection.close();

            this.peerConnection = undefined;

            this.pendingIceCandidates = [];
        }

        if (this.peerConnection) {
            return this.peerConnection;
        }

        const peerConnection =
            new RTCPeerConnection({
                iceServers: [
                    {
                        urls:
                            'stun:stun.l.google.com:19302'
                    }
                ]
            });

        this.peerConnection =
            peerConnection;

        const localStream =
            await this.initializeMedia();

        for (
            const track of
            localStream.getTracks()
        ) {

            peerConnection.addTrack(
                track,
                localStream
            );
        }

        peerConnection.onicecandidate =
            event => {

                if (!event.candidate) {
                    return;
                }

                onIceCandidate(
                    event.candidate.toJSON()
                );
            };

        peerConnection.ontrack =
            event => {

                const stream =
                    event.streams[0];

                if (!stream) {
                    return;
                }

                this.remoteStream =
                    stream;

                this.remoteMediaStream.set(
                    stream
                );
            };

        peerConnection.onconnectionstatechange =
            () => {

                const state =
                    peerConnection.connectionState;

                this.callState.set(
                    state
                );

                const connected =
                    state === 'connected';

                this.callConnected.set(
                    connected
                );

                if (
                    connected &&
                    this.localStream &&
                    !this.audioContext
                ) {
                    void this.startPcmTap(
                        this.localStream
                    );
                }
            };

        return peerConnection;
    }

    async createOffer():
        Promise<RTCSessionDescriptionInit> {

        const peer =
            this.requirePeerConnection();

        const offer =
            await peer.createOffer();

        await peer.setLocalDescription(
            offer
        );

        return offer;
    }

    async acceptOffer(
        offer: RTCSessionDescriptionInit
    ): Promise<RTCSessionDescriptionInit> {

        const peer =
            this.requirePeerConnection();

        await peer.setRemoteDescription(
            offer
        );

        await this.flushPendingIceCandidates();

        const answer =
            await peer.createAnswer();

        await peer.setLocalDescription(
            answer
        );

        return answer;
    }

    async acceptAnswer(
        answer: RTCSessionDescriptionInit
    ): Promise<void> {

        const peer =
            this.requirePeerConnection();

        await peer.setRemoteDescription(
            answer
        );

        await this.flushPendingIceCandidates();
    }

    async addIceCandidate(
        candidate: RTCIceCandidateInit
    ): Promise<void> {

        const peer =
            this.requirePeerConnection();

        if (!peer.remoteDescription) {

            this.pendingIceCandidates.push(
                candidate
            );

            return;
        }

        await peer.addIceCandidate(
            candidate
        );
    }

    private async flushPendingIceCandidates():
        Promise<void> {

        const peer =
            this.requirePeerConnection();

        if (!peer.remoteDescription) {
            return;
        }

        const candidates =
            this.pendingIceCandidates.splice(
                0
            );

        for (
            const candidate of candidates
        ) {

            await peer.addIceCandidate(
                candidate
            );
        }
    }

    private async startPcmTap(
        stream: MediaStream
    ): Promise<void> {

        if (this.audioContext) {
            return;
        }

        const audioTracks =
            stream.getAudioTracks();

        if (audioTracks.length === 0) {

            console.warn(
                '[PCM] No microphone audio track.'
            );

            return;
        }

        const audioContext =
            new AudioContext();

        this.audioContext =
            audioContext;

        console.log(
            '[PCM] AudioContext sampleRate:',
            audioContext.sampleRate
        );

        await audioContext.audioWorklet.addModule(
            '/pcm-audio-processor.js'
        );

        const source =
            audioContext.createMediaStreamSource(
                stream
            );

        this.audioSourceNode =
            source;

        const worklet =
            new AudioWorkletNode(
                audioContext,
                'pcm-audio-processor',
                {
                    processorOptions: {
                        sourceSampleRate:
                            audioContext.sampleRate,

                        targetSampleRate:
                            16000,

                        chunkDurationMs:
                            100
                    }
                }
            );

        this.audioWorkletNode =
            worklet;

        worklet.port.onmessage =
            event => {

                const pcm =
                    event.data as ArrayBuffer;

                void this.sendPcmToNative(
                    pcm
                );
            };

        source.connect(
            worklet
        );

        /*
         * AudioWorkletNode mora biti dio audio grafa
         * kako bi kontinuirano obrađivao mikrofon.
         *
         * Processor na output ne šalje stvarni audio,
         * tako da nećemo čuti vlastiti mikrofon.
         */
        worklet.connect(
            audioContext.destination
        );

        if (
            audioContext.state ===
            'suspended'
        ) {

            await audioContext.resume();
        }

        console.log(
            '[PCM] Shared microphone PCM tap started'
        );
    }

    private async sendPcmToNative(
        buffer: ArrayBuffer
    ): Promise<void> {

        if (
            Capacitor.getPlatform() !==
            'android'
        ) {

            return;
        }

        const bytes =
            new Uint8Array(
                buffer
            );

        const base64 =
            this.bytesToBase64(
                bytes
            );

        try {

            await SpeechRecognition.pushAudio({
                data: base64
            });

        } catch (error) {

            console.error(
                '[PCM] pushAudio failed',
                error
            );
        }
    }

    private bytesToBase64(
        bytes: Uint8Array
    ): string {

        let binary = '';

        const length =
            bytes.length;

        for (
            let index = 0;
            index < length;
            index++
        ) {

            binary += String.fromCharCode(
                bytes[index]
            );
        }

        return btoa(
            binary
        );
    }

    private async stopPcmTap():
        Promise<void> {

        if (this.audioWorkletNode) {

            this.audioWorkletNode.port.onmessage =
                null;

            try {

                this.audioWorkletNode.disconnect();

            } catch {
            }

            this.audioWorkletNode =
                undefined;
        }

        if (this.audioSourceNode) {

            try {

                this.audioSourceNode.disconnect();

            } catch {
            }

            this.audioSourceNode =
                undefined;
        }

        if (this.audioContext) {

            try {

                await this.audioContext.close();

            } catch {
            }

            this.audioContext =
                undefined;
        }

        console.log(
            '[PCM] Shared microphone PCM tap stopped'
        );
    }

    setMicrophoneEnabled(
        enabled: boolean
    ): void {

        if (!this.localStream) {
            return;
        }

        for (
            const track of
            this.localStream.getAudioTracks()
        ) {

            track.enabled =
                enabled;
        }
    }

    setCameraEnabled(
        enabled: boolean
    ): void {

        if (!this.localStream) {
            return;
        }

        for (
            const track of
            this.localStream.getVideoTracks()
        ) {

            track.enabled =
                enabled;
        }
    }

    async endCall():
        Promise<void> {

        await this.stopPcmTap();

        this.peerConnection?.close();

        this.peerConnection =
            undefined;

        if (this.localStream) {

            for (
                const track of
                this.localStream.getTracks()
            ) {

                track.stop();
            }
        }

        this.localStream =
            undefined;

        this.remoteStream =
            undefined;

        this.localMediaStream.set(
            null
        );

        this.remoteMediaStream.set(
            null
        );

        this.callConnected.set(
            false
        );

        this.callState.set(
            'closed'
        );

        this.pendingIceCandidates =
            [];
    }

    private requirePeerConnection():
        RTCPeerConnection {

        if (!this.peerConnection) {

            throw new Error(
                'WebRTC peer connection has not been initialized.'
            );
        }

        return this.peerConnection;
    }
}